<template>
  <div class="col-span-12 lg:col-span-6" v-bind="$attrs">
    <div class="w-full">
      <img :src="require('~/assets/img/buy-and-trade.webp')" class="mt-4 sm:-mt-4" alt="" />
    </div>
  </div>
</template>
